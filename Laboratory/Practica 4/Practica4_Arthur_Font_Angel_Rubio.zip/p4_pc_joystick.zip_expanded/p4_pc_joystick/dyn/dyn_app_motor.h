/*
 * dyn_motor.h
 *
 *  Created on: 18 mar. 2020
 *      Author: droma
 */

#ifndef DYN_MOTOR_H_
#define DYN_MOTOR_H_

#include <stdbool.h>
#include <stdint.h>

void move_forward(void);
void move_backward(void);
void stop_movement(void);
void fast_move_forward(void);
void turn_right(void);
void turn_left(void);

#endif /* DYN_MOTOR_H_ */
