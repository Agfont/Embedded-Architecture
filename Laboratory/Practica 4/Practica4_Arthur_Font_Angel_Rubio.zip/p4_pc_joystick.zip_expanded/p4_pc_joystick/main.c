#include <pthread.h>
#include <signal.h>
#include <assert.h>
#include <stdio.h>

#include "main.h"
#include "dyn/dyn_app_common.h"
#include "dyn/dyn_app_motor.h"
#include "dyn/dyn_app_sensor.h"
#include "dyn_test/dyn_emu.h"
#include "dyn_test/b_queue.h"
#include "joystick_emu/joystick.h"

uint8_t estado = Ninguno, estado_anterior = Ninguno, finalizar = 0;
/**
 * main.c
 */
int main(void)
{
	pthread_t tid, jid;
	uint8_t tmp;
	uint8_t values[3];

	//Init semaphores for TX data handshake
	sem_init(&sem_tx_msp, 0, 0);
	sem_init(&sem_tx_cli, 0, 0);

	//Init queue for RX data
	init_queue();

	//Start thread for dynamixel module emulation
	pthread_create(&tid, NULL, dyn_emu, (void*) &tid);
	pthread_create(&jid, NULL, joystick_emu, (void*) &jid);

	//Testing some high level function
	printf("MAIN: Setting LED to 0 \n");
    dyn_led_control(1, 0);
    printf("MAIN: Getting LED value \n");
    dyn_led_read(1, &tmp);
    assert(tmp == 0);
    printf("MAIN: Setting LED to 1 \n");
	dyn_led_control(1, 1);
	printf("MAIN: Getting LED value \n");
    dyn_led_read(1, &tmp);
    assert(tmp == 1);

    printf("\n\n\n");

    printf("\n       Motor Tests\n");
    printf("MAIN: Moving robot forward \n");
    move_forward();
    test_forward();
    printf("\n\n");

    printf("MAIN: Moving robot Backward \n");
    move_backward();
    test_backward();
    printf("\n\n");

    printf("MAIN: Moving robot fast forward \n");
    fast_move_forward();
    test_fast_forward();
    printf("\n\n");

    printf("MAIN: Stoping robot\n");
    stop_movement();
    test_stop();
    printf("\n\n");

    printf("MAIN: Turning robot to right\n");
	turn_right();
	test_turn_right();
	printf("\n\n");


	printf("MAIN: Turning robot to left \n");
	turn_left();
	test_turn_left();

	printf("\n\n\n");

	printf("\n       Sensor Tests\n");
	tmp = 0;

	values[0] = 100;
	set_front_sensor(values[0]);
	printf("MAIN: Getting Front Sensor value \n");
	test_front_sensor(values[0]);
	get_front_sensor(&tmp);
	printf("MAIN: Front Sensor value is: ");printf("%d", tmp);printf("\n");
	printf("\n\n");

	values[1] = 23;
	set_right_sensor(values[1]);
	printf("MAIN: Getting Right Sensor value \n");
	test_right_sensor(values[1]);
	get_right_sensor(&tmp);
	printf("MAIN: Right Sensor value is: ");printf("%d", tmp);printf("\n");
	printf("\n\n");

	values[2] = 65;
	set_left_sensor(values[2]);
	printf("MAIN: Getting Left Sensor value \n");
	test_left_sensor(values[2]);
	get_left_sensor(&tmp);
	printf("MAIN: Left Sensor value is: ");printf("%d", tmp);printf("\n");
	printf("\n\n");

	printf("************************\n");
	printf("Test passed successfully\n");
	printf("Pulsar 'q' para terminar, qualquier tecla para seguir\r");
	fflush(stdout);//	return 0;

	while(estado != Quit)
	{
		Get_estado(&estado, &estado_anterior);
		if(estado != estado_anterior){
			Set_estado_anterior(estado);
			printf("estado = %d\n", estado);
			fflush(stdout);
			switch(estado){
			case Sw1:
				printf("Boton Sw1 ('a') apretado\n");
				break;
			case Sw2:
				printf("Boton Sw2 ('s') apretado\n");
				break;
			case Quit:
				printf("Adios!\n");
				break;
			//etc, etc...
			}
			fflush(stdout);
		}
	}
	printf("Programa terminado\n");
	//Signal the emulation thread to stop
	pthread_kill(tid, SIGTERM);
	pthread_kill(jid, SIGTERM);
}
