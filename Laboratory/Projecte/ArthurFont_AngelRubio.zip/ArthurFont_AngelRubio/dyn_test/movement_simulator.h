/*
 * movement_simulator.h
 *
 *  Created on: 16 d�abr. 2020
 *      Author: droma
 */

#ifndef DYN_TEST_MOVEMENT_SIMULATOR_H_
#define DYN_TEST_MOVEMENT_SIMULATOR_H_

#include <stdbool.h>
#include <stdint.h>
#include <time.h>

#define SIM_STEP_MS_TIME 10
#define MAX_SIM_STEPS 10000

#define INITIAL_POS_X 50
#define INITIAL_POS_Y 250
#define INITIAL_POS_THETA M_PI_2


typedef struct _robot_pos {
    uint16_t x; // coordenada x
    uint16_t y; // coordenada y
    float theta; // fleja
    int16_t iv_l; // left wheel velocity
    int16_t iv_r; // right wheel velocity
    float v_l; // left wheel velocity (SIMULATOR)
    float v_r; // right wheel velocity (SIMULATOR)
    double r; // is the signed distance from the ICC to the midpoint between the wheels
    double w; // rate of rotation ω
    double icc_x; // cordenada x of ICC (Instantaneous Center of Curvature)
    double icc_y; // cordenada y of ICC (Instantaneous Center of Curvature)
    double x_p; // new position (x)
    double y_p; // new position (y)
    uint64_t sim_step; // robot steps
    const uint32_t *world; // habitación
} _robot_pos_t;

void init_movement_simulator(const uint32_t *world);

void update_movement_simulator_values();

void end_simulator();

void check_colision();

void check_simulation_end();

void check_out_of_bounds();

int32_t timediff(clock_t t1, clock_t t2);

bool elapsed_time(clock_t t1, uint32_t miliseconds, int32_t *true_elapsed_time);

int16_t get_left_wheel_speed(void); // Modificación
int16_t get_right_wheel_speed(void);

#endif /* DYN_TEST_MOVEMENT_SIMULATOR_H_ */
