/*
 * dyn_sensor.h
 *
 *  Created on: 18 mar. 2020
 *      Author: droma
 */

#ifndef DYN_SENSOR_H_
#define DYN_SENSOR_H_

int get_front_sensor(uint8_t *val);
int get_right_sensor(uint8_t *val);
int get_left_sensor(uint8_t *val);

int set_front_sensor(uint8_t val);
int set_right_sensor(uint8_t val);
int set_left_sensor(uint8_t val);


#endif /* DYN_SENSOR_H_ */
