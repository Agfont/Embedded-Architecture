/*
 * dny_app_motor.c
 *
 *  Created on: 20 de abr de 2020
 *      Author: Arthur Font
 */

#include "dyn_app_motor.h"
#include <stdint.h>
#include "dyn/dyn_instr.h"
#include <assert.h>
#include <stdio.h>

typedef uint8_t byte;

/**
 * Move the robot forward
 */
void move_forward(void) {
	byte values[2];
	values[0] = HIGH_SPEED;
	values[1] = 0x03;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
	//values[1] = 0x00;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the forward movement
void test_forward(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == FORWARD);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == 0x00);

    printf("Forward test passed succesfully!\n");
}

/**
 * Move the robot backward
 */
void move_backward(void) {
	byte values[2];
	values[0] = LOW_SPEED;
	values[1] = FORWARD;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);

	//values[1] = FORWARD;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the backward movement
void test_backward(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == 0x00);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == FORWARD);

    printf("Backward test passed succesfully!\n");
}

/**
 * Stop the movement of the robot
 */
void stop_movement(void){
	byte values[2];
	values[0] = 0x00;
	values[1] = 0x00;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);

	values[1] = 0x00;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the stop
void test_stop(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == 0x00);
    assert(value2 == 0x00);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == 0x00);
    assert(value2 == 0x00);

    printf("Stop test passed succesfully!\n");
}

/**
 * Move the robot forward with high speed
 */
void fast_move_forward(void){
	byte values[2];
	values[0] = HIGH_SPEED;
	values[1] = FORWARD;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);

	values[1] = 0x00;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the fast forward movement
void test_fast_forward(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == HIGH_SPEED);
    assert(value2 == FORWARD);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == HIGH_SPEED);
    assert(value2 == 0x00);

    printf("Fast forward test passed succesfully!\n");
}

/**
 * Turn right the robot
 */
void turn_right(void){
	byte values[2];
	values[0] = HIGH_SPEED;
	values[1] = 0x00;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);

    values[0] = LOW_SPEED;
	values[1] = 0x00;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the turn right
void test_turn_right(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == 0x00);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == 0x00);

    printf("Turn right test passed succesfully!\n");
}

/**
 * Turn left the robot
 */
void turn_left(void){
	byte values[2];
	values[0] = LOW_SPEED;
	values[1] = 0x00;
	dyn_write(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);

    values[0] = HIGH_SPEED;
    values[1] = 0x00;
	dyn_write(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, values, sizeof(values) + 1);
}
//Test the turn left
void test_turn_left(){
    byte value1;
    byte value2;
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_L, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == FORWARD);

    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L, &value1);
    dyn_read_byte(ID_MOTOR_R, DYN_REG__GOAL_SPEED_L + 1, &value2);
    assert(value1 == LOW_SPEED);
    assert(value2 == FORWARD);

    printf("Turn left test passed succesfully!\n");
}

/**
 * Turn on the led of specified motor of the robot
 */
void turn_on_leds(bool rLed, bool lLed){
    byte values[2];
    values[0] = DYN_REG__LED;
    values[1] = 1; // Led -> 1 (On)

    // Turn on led of motor right (ID = 2)
    if(rLed) dyn_write(ID_MOTOR_R, DYN_REG__LED, values, sizeof(values) + 1);
    // Turn on led of motor left  (ID = 1)
    if(lLed) dyn_write(ID_MOTOR_L, DYN_REG__LED, values, sizeof(values) + 1);
}

/**
 * Turn off all leds of the robot
 */
void turn_off_leds(void){
    byte values[2];
    values[0] = DYN_REG__LED;
    values[1] = 0; // Led -> 0 (Off)

    dyn_write(ID_MOTOR_R, DYN_REG__LED, values, sizeof(values) + 1);
    dyn_write(ID_MOTOR_L, DYN_REG__LED, values, sizeof(values) + 1);
}
