/*
 * dyn_motor.h
 *
 *  Created on: 18 mar. 2020
 *      Author: droma
 */

#ifndef DYN_MOTOR_H_
#define DYN_MOTOR_H_

#include <stdbool.h>
#include <stdint.h>

#define ID_MOTOR_L 1
#define ID_MOTOR_R 2
#define HIGH_SPEED 0xFF
#define LOW_SPEED 0x40
#define FORWARD 0x04


void move_forward(void);
void move_backward(void);
void stop_movement(void);
void fast_move_forward(void);
void turn_right(void);
void turn_left(void);

void turn_off_leds(void);
void turn_on_leds(bool,bool);

#endif /* DYN_MOTOR_H_ */
