/*
 * dyn_sensor.c
 *
 *  Created on: 18 mar. 2020
 *      Author: droma
 *
 * TODO: High-level functions like "distance_wall_front", etc // DONE
 * TODO: Generate another file for motors, with functions like "move_forward", etc // DONE
 */

#include <stdint.h>
#include "dyn/dyn_app_sensor.h"
#include <assert.h>
#include "dyn/dyn_instr.h"
#include <stdio.h>

typedef uint8_t byte;

#define ID_SENSOR 3

/**
 * Capture information of the front sensor of the robot
 */
int get_front_sensor(uint8_t *val) {
	return dyn_read_byte(ID_SENSOR, DYN_REG__IR_CENTER, val);
}

/**
 * Capture information of the right sensor of the robot
 */
int get_right_sensor(uint8_t *val) {
	return dyn_read_byte(ID_SENSOR, DYN_REG__IR_RIGHT, val);
}

/**
 * Capture information of the left sensor of the robot
 */
int get_left_sensor(uint8_t *val){
	return dyn_read_byte(ID_SENSOR, DYN_REG__IR_LEFT, val);
}

//Set the distance of the front sensor
int set_front_sensor(uint8_t val){
    return dyn_write_byte(ID_SENSOR, DYN_REG__IR_CENTER, val);
}
//Set the distance of the right sensor
int set_right_sensor(uint8_t val){
    return dyn_write_byte(ID_SENSOR, DYN_REG__IR_RIGHT, val);
}
//Set the distance of the left sensor
int set_left_sensor(uint8_t val){
    return dyn_write_byte(ID_SENSOR, DYN_REG__IR_LEFT, val);
}
//Test the front sensor
void test_front_sensor(uint8_t val){
    uint8_t test;
    dyn_read_byte(ID_SENSOR, DYN_REG__IR_CENTER, &test);
    assert(val == test);
    printf("Sensor test passed succesfully!\n");
}
//Test the right sensor
void test_right_sensor(uint8_t val){
    uint8_t test;
    dyn_read_byte(ID_SENSOR, DYN_REG__IR_RIGHT, &test);
    assert(val == test);
    printf("Sensor test passed succesfully!\n");
}
//Test the left sensor
void test_left_sensor(uint8_t val){
    uint8_t test;
    dyn_read_byte(ID_SENSOR, DYN_REG__IR_LEFT, &test);
    assert(val == test);
    printf("Sensor test passed succesfully!\n");
}
