/**
 * Created by arthur on 05/05/2020.
 */

#ifndef ROBOT_CONTROL_H
#define ROBOT_CONTROL_H

#include <stdint.h>
#include <stdbool.h>
#include "dyn/dyn_app_motor.h"
#include "dyn/dyn_frames.h"

#define SECURITY_DIST 2
#define MAX_DIST 10

uint16_t speed;
bool direction;

uint16_t getSpeed();
bool getDirection();

void setSpeed(uint16_t);
void setDirection(bool);

void init();
void start_ride(void);

#endif // ROBOT_CONTROL_H
