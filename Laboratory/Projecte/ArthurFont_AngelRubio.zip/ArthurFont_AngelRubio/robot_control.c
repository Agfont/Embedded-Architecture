/**
 * Created by arthur on 05/05/2020.
 */
#include <stdio.h>
#include "robot_control.h"
#include "dyn/dyn_app_motor.h"
#include "dyn/dyn_frames.h"
#include "dyn/dyn_app_sensor.h"

bool first = true;

void init(){
    speed = LOW_SPEED;
    direction = true;
}

void start_ride(){
    uint8_t left, center, right = 0; // Modificación Arthur
    get_left_sensor(&left);
    get_front_sensor(&center);
    get_right_sensor(&right);//Coger el valor de los 3 sensores
    printf("TEST: Sensors -> (L: %d, C: %d, R: %d)\n", left, center, right);

    if((left < 100 && left > 20) || (right < 100 && right > 20)){//Comprobar si hay alguna pared cerca para seguirla
        if(center > 20){//Si se puede avanzar
            move_forward();//Avanzamos
        }else if(left <= right){//Si hay una pared mas cerca a la izquierda que a la derecha
            turn_right();//Girar a la derecha
        }else if(right < left){//Si hay una pared mas cerca a la derecha que a la izquierda
            turn_left();//Girar a la izquierda
        }
    }else if(left > 100 || right < 20){//Si hay una pared lejos a la izquierda o una muy cerca a la derecha
        turn_left();//Girar a la izquierda
    }else if(left < 20 || right > 100){//Si hay una pared lejos a la derecha o una muy cerca a la izquierda
        turn_right();//Girar a la derecha
    }else{//Si no se cumple ninguna condicion
        turn_left();//Girar a la izquierda
    }
}

void setSpeed(uint16_t vel){
    speed = vel;
}

void setDirection(bool direc){
    direction = direc;
}

uint16_t getSpeed(){
    return speed;
}

bool getDirection(){
    return direction;
}